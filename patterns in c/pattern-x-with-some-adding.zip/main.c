#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int main()

{
    int n;
    scanf("%d",&n);
    for(int i=0;i<n/2;i++){
        for(int j=0;j<n;j++){
            if(i<j&&j<n-i-1){
                printf(" ");
            }
            else{
                printf("*");
            }
        }
        printf("\n");
    }
    for(int i=n/2;i<n;i++){
        for(int j=0;j<n;j++){
            if(i>j&&j>n-i-1){
                printf(" ");
            }
            else{
                printf("*");
            }
        }
        printf("\n");
    }

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}