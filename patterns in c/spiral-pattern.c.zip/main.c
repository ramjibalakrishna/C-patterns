#include<stdio.h>
int main()
{
    int i,j,n;
    scanf("%d",&n);
    int k=n;
    int a[n][n];
    for(i=0;i<n;i++)
    {
        for(j=i;j<n-i;j++)
        {
            a[i][j]=k-i;
        }
        for(j=i+1;j<=n-i-1;j++)
        {
            a[j][n-i-1]=k-i;
        }
        for(j=n-i-2;j>=i;j--)
        {
            a[n-i-1][j]=k-i;
        }
        for(j=n-i-2;j>i;j--)
        {
            a[j][i]=k-i;
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("%d",a[i][j]);
        }
        printf("\n");
    }
    return 0;
}