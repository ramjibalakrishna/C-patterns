/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int n,i,j,k;
   
    scanf("%d",&n);
     int m=n;
    for(i=n;i>0;i--)
    {
        for(k=1;k<=n-i;k++)
        {
            printf(" ");
        }
        for(j=1;j<=i;j++)
        {
            if(j==1||i==n||i==j)
            {
                printf("*");
            }
            else
            {
             printf(" ");
            }
           
        }
        printf("\n");
    }
    

    return 0;
}
