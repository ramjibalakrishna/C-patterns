#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */  
    char a[100];
    int i,j;
    scanf("%s",a);
    int b=strlen(a);
    if(b%2!=0)
    {
    for(i=0;i<=b;i++)
    {
       
        for(j=0;j<b;j++)
        { 
            if(i==j||i+j==b-1)
            {
                printf("%c",a[j]);
            }
            else
            {
                printf(" ");
            }
        }
        printf("\n");
        
    }
    }
    else
    {
        for(i=0;i<=b;i++)
        {
             if(b/2==i)
            {
                continue;
            }
        for(j=0;j<b;j++)
        {
            if(i==j||i+j==b-1)
            {
                {
                   printf("%c",a[j]); 
                }
            }
            else
            {
                printf(" ");
            }
        }
        printf("\n");
      }
    
    return 0;
    }
}

