/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int n,i,j,k,m=1;
     scanf("%d",&n);
    for(i=n;i>0;i--)
    {
       
       for(j=0;j<=i-1;j++)
       {
        
          {
              printf(" ");
          }
       }
       for(k=1;k<=m;k++)
       {
           printf("*");
       }
          
       
      printf("\n");m++;
    }
    

    return 0;
}
